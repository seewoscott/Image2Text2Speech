package com.example.image_recognition_speech_web_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
