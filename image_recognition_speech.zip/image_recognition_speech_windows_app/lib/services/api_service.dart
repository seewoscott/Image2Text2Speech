import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../utils/config.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class ApiService {
  Future<String> recognizeImage(String base64Image,
      {String languageHint = 'zh'}) async {
    try {
      final response = await http.post(
        Uri.parse(
            '${Config.visionApiBaseUrl}/v1/images:annotate?key=${Config.visionApiKey}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'requests': [
            {
              'image': {'content': base64Image},
              'features': [
                {'type': 'TEXT_DETECTION'}
              ],
              'imageContext': {
                'languageHints': [languageHint]
              },
            }
          ],
        }),
      );

      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        if (jsonResponse['responses'] != null &&
            jsonResponse['responses'].isNotEmpty) {
          if (jsonResponse['responses'][0].containsKey('fullTextAnnotation')) {
            return jsonResponse['responses'][0]['fullTextAnnotation']['text'];
          } else {
            throw Exception('No text found in the image');
          }
        } else {
          throw Exception('Empty response from the API');
        }
      } else {
        throw Exception(
            'Failed to recognize image: ${response.statusCode} ${response.reasonPhrase}');
      }
    } catch (e) {
      // 记录错误信息
      if (kDebugMode) {
        print('Error in recognizeImage: $e');
      }
      throw Exception('Failed to recognize image: $e');
    }
  }

  Future<void> speakText(String text, {String languageCode = 'zh-CN'}) async {
    try {
      final response = await http.post(
        Uri.parse(
            '${Config.textToSpeechApiBaseUrl}/v1/text:synthesize?key=${Config.textToSpeechApiKey}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'input': {'text': text},
          'voice': {'languageCode': languageCode, 'ssmlGender': 'FEMALE'},
          'audioConfig': {'audioEncoding': 'MP3'},
        }),
      );

      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        String audioContent = jsonResponse['audioContent'];
        Uint8List audioBytes = base64Decode(audioContent);

        // 将音频数据保存到临时文件
        final tempDir = await getTemporaryDirectory();
        final tempFile = File('${tempDir.path}/temp_audio.mp3');
        await tempFile.writeAsBytes(audioBytes);

        // 使用audioplayers播放音频
        final player = AudioPlayer();
        await player.play(DeviceFileSource(tempFile.path));

        // 监听播放完成事件并释放资源
        player.onPlayerComplete.listen((_) {
          player.dispose();
        });
      } else {
        throw Exception(
            'Failed to synthesize speech: ${response.statusCode} ${response.reasonPhrase}');
      }
    } catch (e) {
      // 记录错误信息
      if (kDebugMode) {
        print('Error in speakText: $e');
      }
      throw Exception('Failed to synthesize speech: $e');
    }
  }

  Future<String> segmentText(String text, String languageCode) async {
    final response = await http.post(
      Uri.parse('${Config.segmentApiBaseUrl}/segment'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'text': text,
        'languageCode': languageCode,
      }),
    );

    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      return jsonResponse['segmentedText'];
    } else {
      throw Exception('Failed to segment text');
    }
  }
}
