import 'package:universal_html/html.dart' as html;
import 'package:flutter/services.dart';

class ClipboardService {
  // 从web端获取剪切板文字
  Future<String?> pickClipboardText() async {
    return await html.window.navigator.clipboard?.readText();
  }

  // 从Windows端获取剪切板文字
  Future<String?> pickClipboardTextWindows() async {
    final clipboardData = await Clipboard.getData('text/plain');
    return clipboardData?.text;
  }
}
