import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart'; // 使用日志框架
import 'package:image_picker/image_picker.dart';
import '../services/image_picker_service.dart';
import '../services/clipboard_service.dart';
import '../services/api_service.dart';
import '../widgets/ui.dart';
import '../utils/Image_processor.dart';

final _logger = Logger('ImagePickerLogic');

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  MyHomePageState createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  final ImagePickerService pickerService = ImagePickerService();
  final ClipboardService clipboardService = ClipboardService();
  final ApiService apiService = ApiService();
  final ImageProcessor imageProcessor = ImageProcessor();

  String result = '';
  String selectedLanguage = 'zh-CN';
  ui.Image? image;
  bool isSelecting = false;
  List<Offset> points = [];
  double brushSize = 10.0;

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      loadImage(bytes);
    }
  }

  Future<void> loadImage(Uint8List bytes) async {
    try {
      final loadedImage = await imageProcessor.loadImage(bytes);
      if (mounted) {
        setState(() {
          image = loadedImage;
          points = [
            Offset.zero,
            Offset(image!.width.toDouble(), 0),
            Offset(image!.width.toDouble(), image!.height.toDouble()),
            Offset(0, image!.height.toDouble()),
          ];
        });
      }
      recognizeSelectedArea();
    } catch (e) {
      _logger.severe('Error loading image', e);
    }
  }

  void updateLanguage(String newLanguage) {
    setState(() {
      selectedLanguage = newLanguage;
    });
  }

  void clearState() {
    setState(() {
      result = '';
      image = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (kDebugMode) {
      print('isSelecting: $isSelecting');
      print('points: $points');
      print('brushSize: $brushSize');
      print('image: $image');
    }
    return MyHomePageUI(this);
  }

  void handlePanUpdate(DragUpdateDetails details) {
    setState(() {
      points.add(details.localPosition);
    });
    if (kDebugMode) {
      print('Updated points: $points');
    }
  }

  Future<void> recognizeSelectedArea() async {
    if (image == null || points.isEmpty) return;

    final selectedBytes =
        await imageProcessor.getSelectedAreaBytes(image!, points);
    final base64Image = base64Encode(selectedBytes);
    final text = await apiService.recognizeImage(base64Image,
        languageHint: selectedLanguage.split('-')[0]);
    setState(() {
      result = text;
    });
    await apiService.speakText(result, languageCode: selectedLanguage);
  }
}
