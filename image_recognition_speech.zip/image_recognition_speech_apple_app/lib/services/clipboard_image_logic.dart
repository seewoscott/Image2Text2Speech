import 'package:logging/logging.dart';
import 'package:universal_html/html.dart';
import '../screens/home_page.dart';
import 'package:pasteboard/pasteboard.dart';

final _logger = Logger('ImagePickerLogic');

extension ClipboardImageLogic on MyHomePageState {
  Future<void> pickClipboardImage() async {
    try {
      // 确保文档聚焦
      if (document.activeElement != null) {
        final imageBytes = await Pasteboard.image;
        if (imageBytes != null) {
          await loadImage(imageBytes);
        } else {
          _logger.warning('剪切板中没有图片');
        }
      } else {
        _logger.warning('文档未聚焦，无法访问剪切板');
      }
    } catch (e) {
      _logger.severe('从剪切板获取图片失败', e);
    }
  }
}
