import 'package:universal_html/html.dart' as html;

class ClipboardService {
  Future<String?> pickClipboardText() async {
    return await html.window.navigator.clipboard?.readText();
  }
}
