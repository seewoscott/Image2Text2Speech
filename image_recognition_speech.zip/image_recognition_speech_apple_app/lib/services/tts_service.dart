import 'package:image_recognition_speech_app/services/api_service.dart';

class TTSService {
  final ApiService _apiService = ApiService();

  Future<void> speak(String text, {required String languageCode}) async {
    await _apiService.speakText(text, languageCode: languageCode);
  }
}
