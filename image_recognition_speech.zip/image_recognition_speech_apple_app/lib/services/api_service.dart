import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import '../utils/config.dart';
import 'package:flutter_sound/flutter_sound.dart';

class ApiService {
  Future<String> recognizeImage(String base64Image,
      {String languageHint = 'zh'}) async {
    final response = await http.post(
      Uri.parse(
          '${Config.visionApiBaseUrl}/v1/images:annotate?key=${Config.visionApiKey}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'requests': [
          {
            'image': {'content': base64Image},
            'features': [
              {'type': 'TEXT_DETECTION'}
            ],
            'imageContext': {
              'languageHints': [languageHint]
            },
          }
        ],
      }),
    );

    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['responses'][0].containsKey('fullTextAnnotation')) {
        return jsonResponse['responses'][0]['fullTextAnnotation']['text'];
      } else {
        throw Exception('No text found in the image');
      }
    } else {
      throw Exception('Failed to recognize image');
    }
  }

  Future<void> speakText(String text, {String languageCode = 'zh-CN'}) async {
    final response = await http.post(
      Uri.parse(
          '${Config.textToSpeechApiBaseUrl}/v1/text:synthesize?key=${Config.textToSpeechApiKey}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'input': {'text': text},
        'voice': {'languageCode': languageCode, 'ssmlGender': 'FEMALE'},
        'audioConfig': {'audioEncoding': 'MP3'},
      }),
    );

    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      String audioContent = jsonResponse['audioContent'];
      Uint8List audioBytes = base64Decode(audioContent);

      FlutterSoundPlayer player = FlutterSoundPlayer();
      await player.openPlayer();
      await player.startPlayer(
        fromDataBuffer: audioBytes,
        codec: Codec.mp3,
      );
    } else {
      throw Exception('Failed to synthesize speech');
    }
  }

  Future<String> segmentText(String text, String languageCode) async {
    final response = await http.post(
      Uri.parse('${Config.segmentApiBaseUrl}/segment'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'text': text,
        'languageCode': languageCode,
      }),
    );

    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      return jsonResponse['segmentedText'];
    } else {
      throw Exception('Failed to segment text');
    }
  }
}
