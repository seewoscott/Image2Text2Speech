import '../screens/home_page.dart';

extension ClipboardTextLogic on MyHomePageState {
  Future<void> pickClipboardText() async {
    final clipboardData = await clipboardService.pickClipboardText();
    if (clipboardData != null) {
      if (mounted) {
        setState(() {
          result = clipboardData;
        });
      }
      await apiService.speakText(clipboardData, languageCode: selectedLanguage);
    }
  }
}
