import 'dart:typed_data';
import 'dart:ui' as ui;
import '../screens/home_page.dart';
import 'package:logging/logging.dart'; // 使用日志框架

final _logger = Logger('ImagePickerLogic');

extension ImagePickerLogic on MyHomePageState {
  Future<void> pickImage() async {
    try {
      final bytes = await pickerService.pickImage();
      if (bytes != null) {
        if (mounted) {
          setState(() {
            isSelecting = false;
            points = [];
          });
        }
        await _loadImage(bytes);
      }
    } catch (e) {
      // 使用日志框架记录错误
      _logger.severe('Error picking image', e);
    }
  }

  Future<void> _loadImage(Uint8List bytes) async {
    try {
      final codec = await ui.instantiateImageCodec(bytes);
      final frameInfo = await codec.getNextFrame();
      if (mounted) {
        setState(() {
          image = frameInfo.image;
        });
      }
    } catch (e) {
      // 使用日志框架记录错误
      _logger.severe('Error loading image', e);
    }
  }
}
