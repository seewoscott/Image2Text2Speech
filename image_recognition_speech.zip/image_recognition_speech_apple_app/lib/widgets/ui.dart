import 'package:flutter/material.dart';
import 'package:image_recognition_speech_app/services/clipboard_image_logic.dart';
import 'package:image_recognition_speech_app/services/clipboard_text_logic.dart';
import 'package:image_recognition_speech_app/services/tts_service.dart';
import '../../../screens/home_page.dart';
import '../utils/string_utils.dart';

class MyHomePageUI extends StatelessWidget {
  final MyHomePageState state;
  final TTSService ttsService = TTSService();

  MyHomePageUI(this.state, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              state.clearState();
            },
            child: const Text(
              '图片识别与语音发音',
              style: TextStyle(
                fontSize: 24, // 调整字体大小
                fontWeight: FontWeight.bold,
                color: Colors.white, // 设置字体颜色
              ),
            ),
          ),
        ),
        backgroundColor: Colors.teal, // 设置 AppBar 背景颜色
      ),
      body: Center(
        child: state.result.isEmpty
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SelectableText(
                        '识别语言: ',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      DropdownButton<String>(
                        value: state.selectedLanguage,
                        onChanged: (String? newValue) {
                          state.updateLanguage(newValue!);
                        },
                        items: <Map<String, String>>[
                          {'value': 'zh-CN', 'label': '中文'},
                          {'value': 'en-US', 'label': '英语'},
                          {'value': 'ja-JP', 'label': '日语'},
                        ].map<DropdownMenuItem<String>>(
                            (Map<String, String> item) {
                          return DropdownMenuItem<String>(
                            value: item['value'],
                            child: Text('${item['label']} (${item['value']})'),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await state.pickImage();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal, // 按钮背景颜色
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                      foregroundColor: Colors.white, // 按钮字体颜色
                    ),
                    child: const Text('选择图片'),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await state.pickClipboardText();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal, // 按钮背景颜色
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                      foregroundColor: Colors.white, // 按钮字体颜色
                    ),
                    child: const Text('从剪切板获取文字'),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await state.pickClipboardImage();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal, // 按钮背景颜色
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                      foregroundColor: Colors.white, // 按钮字体颜色
                    ),
                    child: const Text('从剪切板获取图片'),
                  ),
                  const SizedBox(height: 20),
                  state.image != null ? Container() : Container(),
                ],
              )
            : Wrap(
                spacing: 8.0, // 水平方向的间距
                runSpacing: 4.0, // 垂直方向的间距
                children: splitWords(state.result).asMap().entries.map((entry) {
                  int idx = entry.key;
                  String word = entry.value;
                  if (idx == 0) {
                    return GestureDetector(
                      onTap: () => ttsService.speak(word,
                          languageCode: state.selectedLanguage),
                      child: Text(
                        word,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    );
                  } else {
                    return GestureDetector(
                      onTap: () => ttsService.speak(word,
                          languageCode: state.selectedLanguage),
                      child: Container(
                        padding: const EdgeInsets.all(8.0),
                        decoration: BoxDecoration(
                          color: Colors.teal[50], // 背景颜色与背景色轻微区别
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: InkWell(
                          onTap: () => ttsService.speak(word,
                              languageCode: state.selectedLanguage),
                          child: Text(
                            word,
                            style: const TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                    );
                  }
                }).toList(),
              ),
      ),
    );
  }
}
