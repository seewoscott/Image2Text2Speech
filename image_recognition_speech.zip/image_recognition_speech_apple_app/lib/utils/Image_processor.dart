import 'dart:typed_data';
import 'dart:ui' as ui;
import 'dart:ui';
import '../services/api_service.dart';

class ImageProcessor {
  final ApiService apiService = ApiService();

  Future<Uint8List> getSelectedAreaBytes(
      ui.Image image, List<Offset> points) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);

    final path = Path()..addPolygon(points, true);
    canvas.clipPath(path);
    canvas.drawImage(image, Offset.zero, Paint());

    final picture = recorder.endRecording();
    final img = await picture.toImage(image.width, image.height);
    final byteData = await img.toByteData(format: ui.ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }

  Future<ui.Image> loadImage(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frameInfo = await codec.getNextFrame();
    return frameInfo.image;
  }
}
