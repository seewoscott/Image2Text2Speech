import 'package:flutter_dotenv/flutter_dotenv.dart';

class Config {
  static String get segmentApiBaseUrl => dotenv.env['SEGMENT_API_BASE_URL'] ?? '';

  static String get visionApiKey => dotenv.env['VISION_API_KEY'] ?? '';
  static String get textToSpeechApiKey =>
      dotenv.env['TEXT_TO_SPEECH_API_KEY'] ?? '';
  static String get visionApiBaseUrl => dotenv.env['VISION_API_BASE_URL'] ?? '';
  static String get textToSpeechApiBaseUrl =>
      dotenv.env['TEXT_TO_SPEECH_API_BASE_URL'] ?? '';
}