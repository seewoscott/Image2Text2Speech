// lib/utils/string_utils.dart
List<String> splitWords(String text) {
  const prefix = '识别结果：'; // 识别结果前缀
  // 使用各种标点符号和空格进行词语分割，包括中文和英文和日文的标点符号
  final words = text.split(RegExp(r'[\]\[0-9/=>{}().,;:!?，。；！？（）“”\s]'));
  // 如果是中文，将每个词语拆分成单个字
  if (RegExp(r'[\u4e00-\u9fa5]').hasMatch(text)) {
    final List<String> singleWords = [];
    singleWords.add(prefix);
    for (final word in words) {
      if (word.isNotEmpty) {
        singleWords.addAll(word.split(''));
      }
    }
    return singleWords;
  }
  words.insert(0, prefix);
  return words.where((word) => word.isNotEmpty).toList();
}
